from pathlib import Path
import json, re
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
from sklearn.decomposition import NMF
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=Path('qualcomm_analysis'); OUT.mkdir(exist_ok=True)
d=pd.read_csv('lens-export.csv').fillna('')
# Connected components of overlapping simple-family membership, including each record itself.
parent=list(range(len(d))); seen={}
def root(i):
    while parent[i]!=i:
        parent[i]=parent[parent[i]]; i=parent[i]
    return i
for i,row in d.iterrows():
    for member in set(str(row['Simple Family Members']).split(';;')+[str(row['Lens ID'])]):
        if not member: continue
        if member in seen: parent[root(i)]=root(seen[member])
        else: seen[member]=i
d['family_group']=[root(i) for i in range(len(d))]
# Prefer a representative with an English abstract, then a longer available abstract.
foreign=set('der und die ist des einen eine wobei zum mit von dem einem eines einer oder ein den para que um uma em el la com en una pelo menos del pode dados'.split())
def english(s):
    words=re.findall(r'[a-z]+',s.lower())
    return bool(words) and sum(w in ENGLISH_STOP_WORDS for w in words)/len(words)>.08 and sum(w in ENGLISH_STOP_WORDS for w in words)>sum(w in foreign for w in words)
d['quality']=d['Abstract'].map(lambda s: len(s)*(2 if english(s) else 0))
r=d.sort_values('quality',ascending=False).drop_duplicates('family_group').sort_index().copy()
total_families=len(r)
r=r[r.apply(lambda row: english(row['Abstract']) or english(row['Title']),axis=1)].copy()
r['analysis_text']=r['Title']+' '+r['Abstract'].map(lambda s:s if english(s) else '')
stop=set(ENGLISH_STOP_WORDS)|set('method methods apparatus system systems device devices embodiment embodiments invention present disclosure disclosed provided providing comprises comprising includes including plurality thereof configured said respective corresponding based using used use wherein having associated example examples aspect aspects techniques described relating relates patent second first third determining determine include multiple certain provide dwg cl substance effect'.split())
v=TfidfVectorizer(stop_words=sorted(stop),ngram_range=(1,2),min_df=3,max_df=.85,sublinear_tf=True,strip_accents='unicode',token_pattern=r'(?u)\b[a-zA-Z][a-zA-Z]+\b')
X=v.fit_transform(r['analysis_text']); terms=v.get_feature_names_out()
scores=np.asarray(X.mean(axis=0)).ravel(); df=np.asarray((X>0).sum(axis=0)).ravel()
kw=pd.DataFrame({'term':terms,'mean_tfidf':scores,'family_document_frequency':df}).sort_values('mean_tfidf',ascending=False)
kw.to_csv(OUT/'tfidf_keywords.csv',index=False,encoding='utf-8-sig')
model=NMF(n_components=8,random_state=42,init='nndsvda',max_iter=1000)
W=model.fit_transform(X); H=model.components_
assignment=W.argmax(axis=1); valid=W.max(axis=1)>0
topics=[]
for k in range(8):
    idx=np.where((assignment==k)&valid)[0]
    top=H[k].argsort()[::-1][:18]
    reps=sorted(idx,key=lambda i:W[i,k],reverse=True)[:5]
    topics.append({'topic':k,'families':len(idx),'share_percent':round(len(idx)/len(r)*100,2),'keywords':terms[top].tolist(),'examples':[{'title':r.iloc[i]['Title'],'url':r.iloc[i]['URL']} for i in reps]})
r['topic']=np.where(valid,assignment,-1)
r.drop(columns='quality').to_csv(OUT/'family_topics.csv',index=False,encoding='utf-8-sig')
cpc={}
for s in r['CPC Classifications']:
    for code in set(re.findall(r'\b[A-HY]\d{2}[A-Z]',s)): cpc[code]=cpc.get(code,0)+1
cp=pd.Series(cpc).sort_values(ascending=False); cp.rename('families').to_csv(OUT/'cpc_counts.csv',encoding='utf-8-sig')
meta={'records':len(d),'family_groups':total_families,'analyzed_families':len(r),'excluded_language_families':total_families-len(r),'missing_abstract_records':int((d.Abstract=='').sum()),'missing_abstract_families':int((r.Abstract=='').sum()),'publication_range':[d['Publication Date'].min(),d['Publication Date'].max()],'applicants_qualcomm_records':int(d.Applicants.str.contains('QUALCOMM',case=False).sum()),'topics':topics,'top_cpc':cp.head(15).to_dict(),'keywords':kw.head(40).to_dict('records'),'unassigned':int((~valid).sum())}
(OUT/'results.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
fig,axes=plt.subplots(1,2,figsize=(15,7))
q=kw.head(20).iloc[::-1]; axes[0].barh(q.term,q.mean_tfidf); axes[0].set_title('Mean TF-IDF across family representatives')
axes[1].barh([f'Topic {t["topic"]}: '+', '.join(t['keywords'][:3]) for t in topics][::-1],[t['families'] for t in topics][::-1]); axes[1].set_title('NMF dominant topic: family counts')
fig.tight_layout(); fig.savefig(OUT/'technology_analysis.png',dpi=180)
print(json.dumps(meta,ensure_ascii=True,indent=2))
