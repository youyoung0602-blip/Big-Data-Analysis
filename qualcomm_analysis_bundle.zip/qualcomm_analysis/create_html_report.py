from pathlib import Path
import base64
import html
import re

p = Path(__file__).resolve().parent
source = (p / '퀄컴_기술분석_보고서.md').read_text(encoding='utf-8')
encoded = base64.b64encode((p / 'technology_analysis.png').read_bytes()).decode('ascii')

def inline(text):
    text = html.escape(text)
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    return re.sub(r'\[([^\]]+)\]\((https://[^)]+)\)', r'<a href="\2">\1</a>', text)

out = []
table = False
listing = False
for line in source.splitlines():
    if not line.startswith('|') and table:
        out.append('</tbody></table></div>'); table = False
    if not line.startswith('- ') and listing:
        out.append('</ul>'); listing = False
    if not line.strip():
        continue
    if line.startswith('!['):
        out.append(f'<figure><img alt="퀄컴 특허 TF-IDF 및 기술 주제 분석 그래프" src="data:image/png;base64,{encoded}"></figure>')
    elif line.startswith('#'):
        heading, text = line.split(' ', 1)
        level = len(heading)
        out.append(f'<h{level}>{inline(text)}</h{level}>')
    elif line.startswith('|'):
        cells = [c.strip() for c in line.strip('|').split('|')]
        if all(re.fullmatch(r':?-+:?', c) for c in cells):
            continue
        if not table:
            out.append('<div class="table"><table><thead><tr>' + ''.join(f'<th>{inline(c)}</th>' for c in cells) + '</tr></thead><tbody>')
            table = True
        else:
            out.append('<tr>' + ''.join(f'<td>{inline(c)}</td>' for c in cells) + '</tr>')
    elif line.startswith('- '):
        if not listing:
            out.append('<ul>'); listing = True
        out.append(f'<li>{inline(line[2:])}</li>')
    else:
        out.append(f'<p>{inline(line)}</p>')
if table: out.append('</tbody></table></div>')
if listing: out.append('</ul>')
document = '''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>퀄컴 기술분석 보고서</title><style>
body{font-family:"Malgun Gothic",sans-serif;max-width:1120px;margin:40px auto;padding:0 24px;color:#182536;line-height:1.8}h1,h2,h3{line-height:1.4}h2{margin-top:36px;border-bottom:1px solid #dce3eb;padding-bottom:10px}figure{margin:20px 0}img{width:100%;height:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{border:1px solid #dce3eb;padding:9px 12px;text-align:left}th{background:#edf3f9}.table{overflow-x:auto}a{color:#1762aa}code{background:#f0f3f6;padding:2px 5px}@media print{body{margin:0;max-width:none}table{font-size:10px}h2,h3{break-after:avoid}tr,figure{break-inside:avoid}}</style><main>''' + '\n'.join(out) + '</main></html>'
target = p / '퀄컴_기술분석_보고서.html'
target.write_text(document, encoding='utf-8')
assert 'src="data:image/png;base64,' in document
assert document.count('<table>') == document.count('</table>')
print(f'Created self-contained HTML report ({target.stat().st_size:,} bytes)')
